`define ADDR_Y_HOLD_TIME	8'hA1
`define S_HOLD_TIME 		8'h13
`define CAL_BEFORE_S_END	8'h08
`define S_TO_RST_Y_TIME		8'h04
`define RST_Y_HOLD_TIME 	8'h09
`define RST_Y_TO_R_TIME		8'h3E
`define R_HOLD_TIME		8'h13

